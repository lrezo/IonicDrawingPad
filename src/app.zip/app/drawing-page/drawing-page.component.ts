import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonButtons,
  IonBackButton,
  IonFooter,
} from '@ionic/angular/standalone';

import { DrawingService } from '../drawing-service';

@Component({
  selector: 'app-drawing-page',
  standalone: true,
  templateUrl: './drawing-page.component.html',
  styleUrls: ['./drawing-page.component.scss'],
  imports: [
    IonFooter,
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonButtons,
    IonBackButton,
  ],
})
export class DrawingPageComponent implements AfterViewInit {
  @ViewChild('canvas', { static: false })
  canvasRef!: ElementRef<HTMLCanvasElement>;

  private ctx!: CanvasRenderingContext2D;
  private drawing = false;

  color = '#ffffff';
  size = 5;

  constructor(private drawingService: DrawingService) {}

  ngAfterViewInit(): void {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();

    canvas.width = rect.width;
    canvas.height = rect.height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    this.ctx = ctx;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    this.ctx.fillStyle = '#000000';
    this.ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  private getPos(
    event: MouseEvent | TouchEvent
  ): { x: number; y: number } | null {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();

    if (event instanceof MouseEvent) {
      return {
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
      };
    }

    const touch = event.touches[0] || event.changedTouches[0];
    if (!touch) return null;

    return {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top,
    };
  }

  startDrawing(event: MouseEvent | TouchEvent): void {
    event.preventDefault();
    const pos = this.getPos(event);
    if (!pos) return;

    this.drawing = true;
    this.ctx.strokeStyle = this.color;
    this.ctx.lineWidth = this.size;
    this.ctx.beginPath();
    this.ctx.moveTo(pos.x, pos.y);
  }

  draw(event: MouseEvent | TouchEvent): void {
    if (!this.drawing) return;
    event.preventDefault();

    const pos = this.getPos(event);
    if (!pos) return;

    this.ctx.strokeStyle = this.color;
    this.ctx.lineWidth = this.size;
    this.ctx.lineTo(pos.x, pos.y);
    this.ctx.stroke();
  }

  endDrawing(): void {
    this.drawing = false;
  }

  clearCanvas(): void {
    const canvas = this.canvasRef.nativeElement;
    this.ctx.fillStyle = '#000000';
    this.ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  async save(): Promise<void> {
    const canvas = this.canvasRef.nativeElement;
    const dataUrl = canvas.toDataURL('image/png');
    const base64 = dataUrl.split(',')[1];

    await this.drawingService.SaveDrawing(base64);

    alert('Drawing saved!');
  }
}
